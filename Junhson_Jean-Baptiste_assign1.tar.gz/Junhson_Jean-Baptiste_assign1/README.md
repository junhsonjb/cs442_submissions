# CSX42: Assignment 1
## Name: Junhson Jean-Baptiste

-----------------------------------------------------------------------
-----------------------------------------------------------------------


Following are the commands and the instructions to run ANT on your project.
#### Note: build.xml is present in coursesRegistration/src folder.

-----------------------------------------------------------------------
## Instruction to clean:

####Command: ant -buildfile coursesRegistration/src/build.xml clean

Description: It cleans up all the .class files that were generated when you
compiled your code.

-----------------------------------------------------------------------
## Instruction to compile:

####Command: ant -buildfile coursesRegistration/src/build.xml all

Description: Compiles your code and generates .class files inside the BUILD folder.

-----------------------------------------------------------------------
## Instruction to run:

####Command: ant -buildfile coursesRegistration/src/build.xml run -Darg0="/home/jjeanba2/cs442/Junhson_Jean-Baptiste_assign1/coursesRegistration/src/coursesRegistration/driver/student_coursePrefs.txt" -Darg1="/home/jjeanba2/cs442/Junhson_Jean-Baptiste_assign1/coursesRegistration/src/coursesRegistration/driver/courseInfo.txt" -Darg2="output1_file.txt" -Darg3="output2_file.txt" -Darg4="output3_file.txt"

Note: Arguments accept the absolute path of the files.


-----------------------------------------------------------------------
## Description: My code creates files objects to represent the first 2 input files passed (the others don't matter). We then pass those  files into their own FileProcessor objects, which return an ArrayList of all the Stringss that make up each line from the files. Using   this data, we create a list of Students and a list of Courses, both of which are passed into the constructor of the Scheduler object.    The Scheduler Object runs an algorithm that assigns courses to all Students, giving priority to students who have been around longer. The output from the algorithm is a list of Students along with the courses that were assigned to each Student. This data is passed into the Results object, which implements both the FileDisplayInterface and the StdoutDisplayInterface interfaces to send the resulting data to a file (specified in main) or standard output.


-----------------------------------------------------------------------
### Academic Honesty statement:
-----------------------------------------------------------------------

"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating an official form will be
submitted to the Academic Honesty Committee of the Watson School to
determine the action that needs to be taken. "

Date: September 20, 2019

