package coursesRegistration.util;

public interface StdoutDisplayInterface {

	/**
	 * @return void
	 * write the data from the list of Students (passed into constructor)
	 * out to the standard out
	 */
	public void screenWrite();
	
}
