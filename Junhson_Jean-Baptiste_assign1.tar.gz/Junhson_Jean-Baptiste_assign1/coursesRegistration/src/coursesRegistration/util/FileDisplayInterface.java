package coursesRegistration.util;
import java.io.File;

public interface FileDisplayInterface {

	/**
	 * @return void
	 * write the data from the list of Students (passed into constructor)
	 * out to the passed in file
	 */
	public void fileWrite(File fileIn);
	
}
