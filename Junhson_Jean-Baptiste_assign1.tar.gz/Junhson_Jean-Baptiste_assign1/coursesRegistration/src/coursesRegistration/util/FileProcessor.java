package coursesRegistration.util;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class FileProcessor {

	File file;
	
	// empty constructor -- for housekeeping/good practice
	public FileProcessor() {

	}

	public FileProcessor(File fileIn) {

		this.file = fileIn;

	}

	/**
	 * @return ArrayList<String>
	 * get all the lines from the file, put them in a list and return that list
	 *
	 */
	public ArrayList<String> getLines() {

		ArrayList<String> allLines = new ArrayList<String>();
		BufferedReader buff = null;
		String line = "";
		
		try {

			buff = new BufferedReader(new FileReader(this.file));
			while (line != null) {

				line = buff.readLine();
				if (line != null) {
					allLines.add(line);
				}

			}

		} catch (Exception e) {
			System.out.println(e);
		} finally {

		}

		

		return allLines;

	}
	
}
