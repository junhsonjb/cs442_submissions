package coursesRegistration.util;
import coursesRegistration.scheduler.Student;
import coursesRegistration.scheduler.Course;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Results implements FileDisplayInterface, StdoutDisplayInterface {

	public ArrayList<Student> courseReg; // the completed course registry

	// empty constructor for good housekeeping/good practice
	public Results() {

	}

	public Results(ArrayList<Student> studentsIn) {

		this.courseReg = studentsIn;

	}

	/**
	 * @return void
	 * write the data from the list of Students (passed into constructor)
	 * out to the passed in file
	 */
	public void fileWrite(File fileIn) {

		FileWriter fwriter = null;

		try {

			int totalSatisfaction = 0;
			fwriter = new FileWriter(fileIn);
			for (int ii = 0; ii < courseReg.size(); ii++) {

				fwriter.write(courseReg.get(ii).toString() + "\n");
				totalSatisfaction += courseReg.get(ii).satisfaction;

			}

			// Still need to write avg satisfactionRating!
			float avgSatisfaction = totalSatisfaction / courseReg.size();
			fwriter.write("AverageSatisfactionRating=" + Float.toString(avgSatisfaction) + "\n");

			System.out.println("WE DONE!");

		} catch (IOException io) {
			System.out.println("Encountered IO Exception");
		} finally {

			try {
				fwriter.flush();
				fwriter.close();
			} catch (IOException innerIO) {
				System.out.println("Something went wrong with flushing/closing the file");
			} finally {

			}
		}

	}

	/**
	 * @return void
	 * write the data from the list of Students (passed into constructor)
	 * out to the standard out
	 */
	public void screenWrite() {

		int totalSatisfaction = 0;
		for (int ii = 0; ii < courseReg.size(); ii++) {

			System.out.println(courseReg.get(ii).toString());
			totalSatisfaction += courseReg.get(ii).satisfaction;

		}

		// Still need to write avg satisfactionRating!
		float avgSatisfaction = totalSatisfaction / courseReg.size();
		System.out.println("AverageSatisfactionRating=" + Float.toString(avgSatisfaction));

	}

}
