package coursesRegistration.scheduler;
import coursesRegistration.scheduler.Student;
import coursesRegistration.scheduler.Course;
import coursesRegistration.scheduler.Priority;
import java.util.ArrayList;

public class Scheduler {

	ArrayList<Student> students;
	ArrayList<Course> courses;

	// just an empty constructor for housekeeping/good practice
	public Scheduler() {

	}

	public Scheduler(ArrayList<Student> studentsIn, ArrayList<Course> coursesIn) {

		this.students = studentsIn;
		this.courses = coursesIn;

	}

	/**
	 * @return Course
	 * Given the name of a course (String), return the course that has that name
	 */
	public Course matchCourse(ArrayList<Course> courseList, String nameIn) {

		for (Course c : courseList) {

			if (nameIn.equals(c.name)) {
				return c;
			}

		}

		return null;

	}

	/**
	 * @return ArrayList<Student>
	 * Assign courses to all the students, return a list of Students who have
	 * courses assigned to them
	 */
	public ArrayList<Student> assignCourses() {

		ArrayList<Student> thirdYears = new ArrayList<Student>();
		ArrayList<Student> secondYears = new ArrayList<Student>();
		ArrayList<Student> firstYears = new ArrayList<Student>();

		for (Student s : students) {

			if (s.level == Priority.THIRD_YEAR) {
				thirdYears.add(s);
			}

			if (s.level == Priority.SECOND_YEAR) {
				secondYears.add(s);
			}

			if (s.level == Priority.FIRST_YEAR) {
				firstYears.add(s);
			}

		}

		// Assign Desired Courses to Third Year Students

		for (Student stud : thirdYears) {

			// create a list of Courses in stud's preffered order
			ArrayList<Course> prefs = new ArrayList<Course>();

			for (String str : stud.preferences) {

				Course c = matchCourse(courses, str);
				prefs.add(c);

			}

			// add the three best choice courses for stud
			for (int ii = 0; ii < prefs.size(); ii++) {

				if (stud.coursesRecieved.size() == 3) {
					break; // this means we've reached the maximum number of courses for stud
				}

				boolean added = stud.addCourse(prefs.get(ii));

				// if (added) {
				// 	
				// } else {

				// }

			}

		}

		// Do similar assignment for second year students
		for (Student stud : secondYears) {

			// create a list of Courses in stud's preffered order
			ArrayList<Course> prefs = new ArrayList<Course>();

			for (String str : stud.preferences) {

				Course c = matchCourse(courses, str);
				prefs.add(c);

			}

			// add the three best choice courses for stud
			for (int ii = 0; ii < prefs.size(); ii++) {

				if (stud.coursesRecieved.size() == 3) {
					break; // this means we've reached the maximum number of courses for stud
				}

				boolean added = stud.addCourse(prefs.get(ii));

				// if (added) {
				// 	
				// } else {

				// }

			}

		}

		// Do similar asignment for first year students
		for (Student stud : firstYears) {

			// create a list of Courses in stud's preffered order
			ArrayList<Course> prefs = new ArrayList<Course>();

			for (String str : stud.preferences) {

				Course c = matchCourse(courses, str);
				prefs.add(c);

			}

			// add the three best choice courses for stud
			for (int ii = 0; ii < prefs.size(); ii++) {

				if (stud.coursesRecieved.size() == 3) {
					break; // this means we've reached the maximum number of courses for stud
				}

				boolean added = stud.addCourse(prefs.get(ii));

				// if (added) {
				// 	
				// } else {

				// }

			}

		}

		// Now congregate all the students in one list and return it!
		ArrayList<Student> registeredStudents = new ArrayList<Student>();

		for (Student x : thirdYears) {
			registeredStudents.add(x);
		}

		for (Student x : secondYears) {
			registeredStudents.add(x);
		}

		for (Student x : firstYears) {
			registeredStudents.add(x);
		}

		return registeredStudents;

	}

}
