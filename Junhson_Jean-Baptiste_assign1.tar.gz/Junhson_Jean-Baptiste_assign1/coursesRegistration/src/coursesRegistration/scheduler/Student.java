package coursesRegistration.scheduler;
import java.util.ArrayList;

public class Student {

	// public enum Priority { FIRST_YEAR, SECOND_YEAR, THIRD_YEAR } // moved to separate file

	public int idNumber;
	public ArrayList<String> preferences;
	public ArrayList<Course> coursesRecieved;
	public Priority level;
	public int satisfaction;

	public Student(int idIn, ArrayList<String> prefsIn, String levelIn) {

		this.idNumber = idIn;
		this.preferences = prefsIn;
		// this.level = levelIn;
		if (levelIn.equals("THIRD_YEAR")) { this.level = Priority.THIRD_YEAR; }
		else if (levelIn.equals("SECOND_YEAR")) { this.level = Priority.SECOND_YEAR; }
		else { this.level = Priority.FIRST_YEAR; } // if nothing is correctly specified, then assign lowest

		coursesRecieved = new ArrayList<Course>();

	}

	/**
     * @return boolean
     * If possible, add the passed in course to the coursesRecieved list
	 */
	public boolean addCourse(Course courseIn) {

		if (coursesRecieved.size() >= 3) {
			return false;
		}

		for (Course c : coursesRecieved) {
			if (c.time == courseIn.time) {
				return false;
			}
		}

		if (courseIn.seatsTaken >= courseIn.capacity) {
			return false;
		}

		// otherwise, add courseIn to the coursesRecieved list
		coursesRecieved.add(courseIn);
		return true;

	}

	/**
     * @return int
     * compute the satisfaction rating for this student based off the 
	 * courses that they got placed into
	 */
	public int computeSatisfaction() {

		int total = 0;

		for (Course c : coursesRecieved) {

			int subValue = preferences.indexOf(c.name);
			total += (9 - subValue);

		}

		this.satisfaction = total;
		return total;

	}

	/**
     * @return String
	 * toString for the class
	 */
	public String toString() {

		String ret = "";
		int satisfactionHolder = computeSatisfaction();
		ret += Integer.toString(this.idNumber) + ":";
		for (int ii = 0; ii < coursesRecieved.size() - 1; ii++) {
			ret += coursesRecieved.get(ii).name + ",";
		}
		ret += coursesRecieved.get(coursesRecieved.size() - 1).name + "::";
		ret += "SatisfactionRating=" + Integer.toString(this.satisfaction);

		return ret;

	}

}
