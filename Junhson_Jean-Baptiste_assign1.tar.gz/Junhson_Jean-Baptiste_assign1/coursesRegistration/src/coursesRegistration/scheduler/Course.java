package coursesRegistration.scheduler;

public class Course {

	public String name;
	public int capacity;
	public int time;
	public int seatsTaken;

	public Course(String nameIn, int capacityIn, int timeIn) {

		this.name = nameIn;
		this.capacity = capacityIn;
		this.time = timeIn;

	}

	/**
	 * @return boolean
	 * if possible, increment the amount of seats taken for this course
	 */
	public boolean addStudent() {

		if (seatsTaken < capacity) {
			seatsTaken += 1;
			return true;
		}

		return false;

	}

	/**
	 * @return String
	 * toString for the class
	 */
	public String toString() {

		String ret = "Course name: " + this.name + "; Course time: " + this.time + "; Capacity: " + this.capacity;
		return ret;

	}

}
