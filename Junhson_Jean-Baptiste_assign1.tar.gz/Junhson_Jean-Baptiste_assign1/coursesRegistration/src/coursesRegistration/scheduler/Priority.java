package coursesRegistration.scheduler;

public enum Priority {
	 FIRST_YEAR, SECOND_YEAR, THIRD_YEAR
}
