package coursesRegistration.driver;
import coursesRegistration.util.FileProcessor;
import coursesRegistration.util.Results;
import coursesRegistration.scheduler.Student;
import coursesRegistration.scheduler.Course;
import coursesRegistration.scheduler.Scheduler;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

/**
 * @author Junhson Jean-Baptiste
 *
 */
public class Driver {
	public static void main(String[] args) {

		/*
		 * As the build.xml specifies the arguments as argX, in case the
		 * argument value is not given java takes the default value specified in
		 * build.xml. To avoid that, below condition is used
		 */
		if (args.length != 5 || args[0].equals("${arg0}") || args[1].equals("${arg1}") || args[2].equals("${arg2}")
				|| args[3].equals("${arg3}") || args[4].equals("${arg4}")) {

			System.err.println("Error: Incorrect number of arguments. Program accepts 5 argumnets.");
			System.exit(0);
		}
		
		System.out.println("Hello World! Lets get started with the assignment");

		/* We will assume the following input order
		arg1 - student course prefs
		arg2 - course info
		arg3 - (are there any more args???)
		*/

		System.out.printf("student couse prefs file is called %s\ncourse info file is called %s\n", args[0], args[1]);

		File studentsFile = null;
		File coursesFile = null;

		try {
			studentsFile = new File(args[0]);
			coursesFile = new File(args[1]);
		} catch (Exception e) {
			System.out.println("Something went wrong");
		} finally {

		}

		// maybe find a way to use these later, for now just keep going
		// FileProcessor studentFile = new FileProcessor(args[0]);
		// FileProcessor courseFile = new FileProcessor(args[1]);

		ArrayList<Student> students = generateStudentList(studentsFile); //write this func
		ArrayList<Course> courses = generateCourseList(coursesFile); //write this func

		Scheduler sched = new Scheduler(students, courses);
		ArrayList<Student> resultsList = sched.assignCourses();

		Results res = new Results(resultsList);
		String outputFilename = "/home/jjeanba2/cs442/Junhson_Jean-Baptiste_assign1/coursesRegistration/src/coursesRegistration/driver/registration_results.txt";
		try {
			File outputFile = new File(outputFilename);
			res.fileWrite(outputFile);
		} catch (Exception e) {
			System.out.println("Something went wrong");
		} finally {

		}
		res.screenWrite();

		System.out.println("Yay it worked");

	}

/**
 * @return ArrayList<Course>
 * Return a list of all the courses from the passed in file
 */
	static ArrayList<Course> generateCourseList(File input) {

		ArrayList<Course> list = new ArrayList<Course>();
		ArrayList<String> lines;
		FileProcessor fproc = new FileProcessor(input);

		lines = fproc.getLines();

		for (String line : lines) {

			String[] splitLine = line.split(";");
			String nameCap = splitLine[0];
			String timing = splitLine[1];

			String courseName = nameCap.substring(0, 1);
			int courseCapacity = Integer.parseInt(nameCap.substring(11));
			int courseTime = Integer.parseInt(timing.substring(13));

			Course course = new Course(courseName, courseCapacity, courseTime);
			list.add(course);

		}

		return list;

	}

/**
 * @return ArrayList<Student>
 * Return a list of all the students from the passed in file
 */
	static ArrayList<Student> generateStudentList(File input) {

		ArrayList<Student> list = new ArrayList<Student>();
		ArrayList<String> lines;
		FileProcessor fproc = new FileProcessor(input);

		lines = fproc.getLines();

		// turn each line into a Student object
		for (String line : lines) {

			String idString = line.substring(0, 3);
			int id = Integer.parseInt(idString);
			String preferences = line.substring(4, 21);
			String level = line.substring(23);

			String[] prefsArray = preferences.split(",");
			ArrayList<String> prefs = new ArrayList<String>();

			for (String str : prefsArray) {
				prefs.add(str);
			}

			Student student = new Student(id, prefs, level);
			list.add(student);

		}

		return list;
	}
	
}

